--!strict
-- Secure World-space constructor for SiegeFPS Map Assets
local Workspace = game:GetService("Workspace")

local function buildBarrier(name: string, size: Vector3, position: Vector3, material: Enum.Material, color: Color3)
    local p = Instance.new("Part")
    p.Name = name
    p.Size = size
    p.Position = position
    p.Material = material
    p.Color = color
    p.Anchored = true
    p.CanCollide = true
    p.Parent = Workspace
end

-- Generate dynamic, server-authoritative tactical wall structures
buildBarrier("Baseplate", Vector3.new(2048, 16, 2048), Vector3.new(0, -8, 0), Enum.Material.Concrete, Color3.fromRGB(80, 80, 85))
buildBarrier("Tactical_Wall_Alpha", Vector3.new(4, 15, 60), Vector3.new(25, 7.5, 0), Enum.Material.Concrete, Color3.fromRGB(60, 60, 60))
buildBarrier("Tactical_Wall_Beta", Vector3.new(4, 15, 60), Vector3.new(-25, 7.5, 0), Enum.Material.Concrete, Color3.fromRGB(60, 60, 60))
buildBarrier("Shooting_Backwall", Vector3.new(120, 30, 4), Vector3.new(0, 15, -80), Enum.Material.DiamondPlate, Color3.fromRGB(40, 40, 40))

print("[WORLD ENGINE] Standard baseplate and tactical barriers built securely.")