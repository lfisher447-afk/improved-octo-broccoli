--!strict
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local SharedApp = ReplicatedStorage:WaitForChild("App")
local WeaponConfig = require(SharedApp.Config.WeaponConfig)
local ProceduralModeler = require(SharedApp.Utilities.ProceduralModeler)

local WeaponController = { Name = "WeaponController" }
local me = Players.LocalPlayer
local currentWeaponName = "Saqire367" -- Dragon scoped sniper on start
local activeViewModel: Model? = nil

local function renderViewModel()
    if activeViewModel then activeViewModel:Destroy() end
    
    local model = ProceduralModeler.buildWeapon(currentWeaponName)
    local camera = workspace.CurrentCamera
    model.Parent = camera
    activeViewModel = model
    
    -- Weld gun procedurally to viewport camera coordinates
    RunService:BindToRenderStep("ViewModelRig", Enum.RenderPriority.Camera.Value - 1, function()
        if not activeViewModel or not activeViewModel.PrimaryPart then return end
        local cf = camera.CFrame * CFrame.new(0.5, -0.6, -1.5)
        activeViewModel:PivotTo(cf)
    end)
end

function WeaponController:Start()
    if me == nil then return end
    
    me.CharacterAdded:Connect(function(char)
        renderViewModel()
    end)
    
    if me.Character then
        renderViewModel()
    end

    -- Capture tactical combat clicks
    UserInputService.InputBegan:Connect(function(input, processed)
        if processed then return end
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            local camera = workspace.CurrentCamera
            local ray = camera:ViewportPointToRay(camera.ViewportSize.X / 2, camera.ViewportSize.Y / 2)
            
            -- Call secure replication damage remote
            local targetPlayer = Players:GetPlayers()[2] -- Mock target index
            if targetPlayer then
                local remotes = SharedApp:WaitForChild("Remotes")
                local dealDamage = remotes:WaitForChild("DealDamage") :: RemoteEvent
                dealDamage:FireServer(targetPlayer, targetPlayer.Character.PrimaryPart.Position, true, currentWeaponName, ray.Origin, ray.Direction)
            end
        end
    end)
end

return WeaponController