--strict
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")

local SharedApp = ReplicatedStorage:WaitForChild("App")
local Names = require(SharedApp.Networking.AntiCheatRemotes)
local Packets = require(SharedApp.Networking.QBPackets)

local DeviosUIController = { Name = "DeviosUIController" }
local me = Players.LocalPlayer

local function buildUI(adminLink: RemoteEvent, sessionSeed: number, bansList: any, currentAdmins: any, currentGroup: any)
    local screen = Instance.new("ScreenGui")
    screen.Name = "DeviosPanel"
    screen.ResetOnSpawn = false
    screen.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

    local main = Instance.new("Frame")
    main.Size = UDim2.new(0, 500, 0, 320)
    main.Position = UDim2.new(0.5, -250, 0.5, -160)
    main.BackgroundColor3 = Color3.fromRGB(12, 12, 12)
    main.BorderSizePixel = 2
    main.BorderColor3 = Color3.fromRGB(0, 255, 65)
    main.Parent = screen

    -- Top Header Panel
    local header = Instance.new("TextLabel")
    header.Size = UDim2.new(1, 0, 0, 35)
    header.BackgroundColor3 = Color3.fromRGB(5, 5, 5)
    header.Text = " [ DEVIOS SENTINEL v5.0 CONTROL DECK ]"
    header.TextColor3 = Color3.fromRGB(0, 255, 65)
    header.Font = Enum.Font.Code
    header.TextSize = 13
    header.TextXAlignment = Enum.TextXAlignment.Left
    header.Parent = main

    local close = Instance.new("TextButton")
    close.Size = UDim2.new(0, 30, 0, 30)
    close.Position = UDim2.new(1, -32, 0, 2)
    close.BackgroundTransparency = 1
    close.Text = "✕"
    close.TextColor3 = Color3.fromRGB(255, 0, 0)
    close.Font = Enum.Font.Code
    close.TextSize = 16
    close.Parent = main

    -- Sidebar Tabs
    local playersTab = Instance.new("TextButton")
    playersTab.Size = UDim2.new(0, 100, 0, 30)
    playersTab.Position = UDim2.new(0, 10, 0, 45)
    playersTab.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    playersTab.Text = "[ PLAYERS ]"
    playersTab.TextColor3 = Color3.fromRGB(0, 255, 65)
    playersTab.Font = Enum.Font.Code
    playersTab.Parent = main

    local bansTab = Instance.new("TextButton")
    bansTab.Size = UDim2.new(0, 100, 0, 30)
    bansTab.Position = UDim2.new(0, 115, 0, 45)
    bansTab.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    bansTab.Text = "[ BAN LIST ]"
    bansTab.TextColor3 = Color3.fromRGB(0, 255, 65)
    bansTab.Font = Enum.Font.Code
    bansTab.Parent = main

    local rolesTab = Instance.new("TextButton")
    rolesTab.Size = UDim2.new(0, 100, 0, 30)
    rolesTab.Position = UDim2.new(0, 220, 0, 45)
    rolesTab.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
    rolesTab.Text = "[ ROLE SETUP ]"
    rolesTab.TextColor3 = Color3.fromRGB(0, 255, 65)
    rolesTab.Font = Enum.Font.Code
    rolesTab.Parent = main

    -- Container Panels for tabs
    local playersFrame = Instance.new("Frame")
    playersFrame.Size = UDim2.new(1, -20, 1, -85)
    playersFrame.Position = UDim2.new(0, 10, 0, 80)
    playersFrame.BackgroundTransparency = 1
    playersFrame.Parent = main

    local bansFrame = Instance.new("Frame")
    bansFrame.Size = UDim2.new(1, -20, 1, -85)
    bansFrame.Position = UDim2.new(0, 10, 0, 80)
    bansFrame.BackgroundTransparency = 1
    bansFrame.Visible = false
    bansFrame.Parent = main

    local rolesFrame = Instance.new("Frame")
    rolesFrame.Size = UDim2.new(1, -20, 1, -85)
    rolesFrame.Position = UDim2.new(0, 10, 0, 80)
    rolesFrame.BackgroundTransparency = 1
    rolesFrame.Visible = false
    rolesFrame.Parent = main

    local selectedPlayer: Player? = nil

    -- --- 1. PLAYERS TUBE LOGIC ---
    local scrollingFrame = Instance.new("ScrollingFrame")
    scrollingFrame.Size = UDim2.new(0, 220, 1, 0)
    scrollingFrame.BackgroundTransparency = 0.8
    scrollingFrame.BackgroundColor3 = Color3.fromRGB(0,0,0)
    scrollingFrame.CanvasSize = UDim2.new(0, 0, 5, 0)
    scrollingFrame.Parent = playersFrame

    local layout = Instance.new("UIListLayout")
    layout.Padding = UDim.new(0, 4)
    layout.Parent = scrollingFrame

    local selectedLabel = Instance.new("TextLabel")
    selectedLabel.Size = UDim2.new(0, 240, 0, 25)
    selectedLabel.Position = UDim2.new(0, 230, 0, 5)
    selectedLabel.BackgroundTransparency = 1
    selectedLabel.Text = "Target: None"
    selectedLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    selectedLabel.Font = Enum.Font.Code
    selectedLabel.TextSize = 12
    selectedLabel.Parent = playersFrame

    local kickBtn = Instance.new("TextButton")
    kickBtn.Size = UDim2.new(0, 240, 0, 35)
    kickBtn.Position = UDim2.new(0, 230, 0, 40)
    kickBtn.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    kickBtn.Text = "Execute Kick"
    kickBtn.TextColor3 = Color3.fromRGB(255, 140, 0)
    kickBtn.Font = Enum.Font.Code
    kickBtn.Parent = playersFrame

    local banBtn = Instance.new("TextButton")
    banBtn.Size = UDim2.new(0, 240, 0, 35)
    banBtn.Position = UDim2.new(0, 230, 0, 85)
    banBtn.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    banBtn.Text = "Hardware Ban"
    banBtn.TextColor3 = Color3.fromRGB(255, 0, 0)
    banBtn.Font = Enum.Font.Code
    banBtn.Parent = playersFrame

    local bringBtn = Instance.new("TextButton")
    bringBtn.Size = UDim2.new(0, 240, 0, 35)
    bringBtn.Position = UDim2.new(0, 230, 0, 130)
    bringBtn.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    bringBtn.Text = "Warp Bring"
    bringBtn.TextColor3 = Color3.fromRGB(0, 255, 65)
    bringBtn.Font = Enum.Font.Code
    bringBtn.Parent = playersFrame

    local gotoBtn = Instance.new("TextButton")
    gotoBtn.Size = UDim2.new(0, 240, 0, 35)
    gotoBtn.Position = UDim2.new(0, 230, 0, 175)
    gotoBtn.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    gotoBtn.Text = "Warp Goto"
    gotoBtn.TextColor3 = Color3.fromRGB(0, 255, 65)
    gotoBtn.Font = Enum.Font.Code
    gotoBtn.Parent = playersFrame

    local function refreshList()
        for _, c in ipairs(scrollingFrame:GetChildren()) do
            if c:IsA("TextButton") then c:Destroy() end
        end
        for _, p in ipairs(Players:GetPlayers()) do
            if p == me then continue end
            local pBtn = Instance.new("TextButton")
            pBtn.Size = UDim2.new(1, -10, 0, 25)
            pBtn.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
            pBtn.Text = p.Name
            pBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
            pBtn.Font = Enum.Font.Code
            pBtn.Parent = scrollingFrame

            pBtn.MouseButton1Click:Connect(function()
                selectedPlayer = p
                selectedLabel.Text = "Target: " .. p.Name
            end)
        end
    end

    refreshList()

    -- --- 2. BANS LIST TUBE LOGIC ---
    local bansScroll = Instance.new("ScrollingFrame")
    bansScroll.Size = UDim2.new(1, 0, 1, 0)
    bansScroll.BackgroundTransparency = 0.8
    bansScroll.BackgroundColor3 = Color3.fromRGB(0,0,0)
    bansScroll.CanvasSize = UDim2.new(0, 0, 10, 0)
    bansScroll.Parent = bansFrame

    local bansLayout = Instance.new("UIListLayout")
    bansLayout.Padding = UDim.new(0, 4)
    bansLayout.Parent = bansScroll

    local function refreshBans()
        for _, c in ipairs(bansScroll:GetChildren()) do
            if c:IsA("Frame") then c:Destroy() end
        end
        for userId, data in pairs(bansList) do
            local banRow = Instance.new("Frame")
            banRow.Size = UDim2.new(1, -10, 0, 45)
            banRow.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
            banRow.Parent = bansScroll

            local txt = Instance.new("TextLabel")
            txt.Size = UDim2.new(0.8, 0, 1, 0)
            txt.BackgroundTransparency = 1
            txt.Text = " ID: " .. tostring(userId) .. " | " .. tostring(data.Reason)
            txt.TextColor3 = Color3.fromRGB(255, 65, 65)
            txt.Font = Enum.Font.Code
            txt.TextSize = 10
            txt.TextXAlignment = Enum.TextXAlignment.Left
            txt.Parent = banRow
        end
    end

    refreshBans()

    -- --- 3. ROLES TUBE LOGIC ---
    local userBoxLabel = Instance.new("TextLabel")
    userBoxLabel.Size = UDim2.new(0, 200, 0, 25)
    userBoxLabel.Position = UDim2.new(0, 10, 0, 5)
    userBoxLabel.BackgroundTransparency = 1
    userBoxLabel.Text = "Whitelist Admin Usernames:"
    userBoxLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    userBoxLabel.Font = Enum.Font.Code
    userBoxLabel.TextXAlignment = Enum.TextXAlignment.Left
    userBoxLabel.Parent = rolesFrame

    local adminInput = Instance.new("TextBox")
    adminInput.Size = UDim2.new(0, 220, 0, 30)
    adminInput.Position = UDim2.new(0, 10, 0, 35)
    adminInput.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    adminInput.TextColor3 = Color3.fromRGB(0, 255, 65)
    adminInput.Font = Enum.Font.Code
    adminInput.Text = ""
    adminInput.PlaceholderText = "Separate by comma"
    adminInput.Parent = rolesFrame

    local groupBoxLabel = Instance.new("TextLabel")
    groupBoxLabel.Size = UDim2.new(0, 200, 0, 25)
    groupBoxLabel.Position = UDim2.new(0, 10, 0, 80)
    groupBoxLabel.BackgroundTransparency = 1
    groupBoxLabel.Text = "Roblox Group Integration:"
    groupBoxLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    groupBoxLabel.Font = Enum.Font.Code
    groupBoxLabel.TextXAlignment = Enum.TextXAlignment.Left
    groupBoxLabel.Parent = rolesFrame

    local groupIdInput = Instance.new("TextBox")
    groupIdInput.Size = UDim2.new(0, 105, 0, 30)
    groupIdInput.Position = UDim2.new(0, 10, 0, 110)
    groupIdInput.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    groupIdInput.TextColor3 = Color3.fromRGB(0, 255, 65)
    groupIdInput.Font = Enum.Font.Code
    groupIdInput.Text = tostring(currentGroup.GroupId)
    groupIdInput.PlaceholderText = "Group ID"
    groupIdInput.Parent = rolesFrame

    local rankIdInput = Instance.new("TextBox")
    rankIdInput.Size = UDim2.new(0, 105, 0, 30)
    rankIdInput.Position = UDim2.new(0, 125, 0, 110)
    rankIdInput.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
    rankIdInput.TextColor3 = Color3.fromRGB(0, 255, 65)
    rankIdInput.Font = Enum.Font.Code
    rankIdInput.Text = tostring(currentGroup.MinRank)
    rankIdInput.PlaceholderText = "Min Rank"
    rankIdInput.Parent = rolesFrame

    local saveRolesBtn = Instance.new("TextButton")
    saveRolesBtn.Size = UDim2.new(0, 220, 0, 35)
    saveRolesBtn.Position = UDim2.new(0, 10, 0, 160)
    saveRolesBtn.BackgroundColor3 = Color3.fromRGB(0, 150, 40)
    saveRolesBtn.Text = "Save Role Config"
    saveRolesBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
    saveRolesBtn.Font = Enum.Font.Code
    saveRolesBtn.Parent = rolesFrame

    -- Populate roles whitelist on start
    local wl = {}
    for name, _ in pairs(currentAdmins) do
        table.insert(wl, name)
    end
    adminInput.Text = table.concat(wl, ", ")

    -- Switch Tab Actions
    playersTab.MouseButton1Click:Connect(function()
        playersFrame.Visible = true
        bansFrame.Visible = false
        rolesFrame.Visible = false
    end)

    bansTab.MouseButton1Click:Connect(function()
        playersFrame.Visible = false
        bansFrame.Visible = true
        rolesFrame.Visible = false
        refreshBans()
    end)

    rolesTab.MouseButton1Click:Connect(function()
        playersFrame.Visible = false
        bansFrame.Visible = false
        rolesFrame.Visible = true
    end)

    close.MouseButton1Click:Connect(function()
        screen:Destroy()
    end)

    -- Commands execution triggers with dynamic salted security hash tokens
    kickBtn.MouseButton1Click:Connect(function()
        if selectedPlayer then
            local token = Packets.generateHash(sessionSeed, me.UserId, 10)
            adminLink:FireServer("Kick", selectedPlayer.UserId, token, "Removed by Devios Sentinel deck.")
        end
    end)

    banBtn.MouseButton1Click:Connect(function()
        if selectedPlayer then
            local token = Packets.generateHash(sessionSeed, me.UserId, 20)
            adminLink:FireServer("Ban", selectedPlayer.UserId, token, "Hardware ban logged by Administrator.")
        end
    end)

    bringBtn.MouseButton1Click:Connect(function()
        if selectedPlayer then
            local token = Packets.generateHash(sessionSeed, me.UserId, 30)
            adminLink:FireServer("Bring", selectedPlayer.UserId, token)
        end
    end)

    gotoBtn.MouseButton1Click:Connect(function()
        if selectedPlayer then
            local token = Packets.generateHash(sessionSeed, me.UserId, 40)
            adminLink:FireServer("Goto", selectedPlayer.UserId, token)
        end
    end)

    saveRolesBtn.MouseButton1Click:Connect(function()
        local admins = {}
        for part in string.gmatch(adminInput.Text, "[^,%s]+") do
            table.insert(admins, part)
        end
        local payload = {
            Admins = admins,
            Group = {
                GroupId = tonumber(groupIdInput.Text) or 0,
                MinRank = tonumber(rankIdInput.Text) or 255
            }
        }
        local token = Packets.generateHash(sessionSeed, me.UserId, 50)
        adminLink:FireServer("SaveRoles", 0, token, payload)
    end)

    screen.Parent = me:WaitForChild("PlayerGui")
end

function DeviosUIController:Start()
    if me == nil then return end
    local remotes = SharedApp:WaitForChild("Remotes")
    local adminVerify = remotes:WaitForChild(Names.adminVerify) :: RemoteFunction
    local adminLink = remotes:WaitForChild(Names.adminLink) :: RemoteEvent

    local authorized, sessionSeed, activeBans, currentAdmins, currentGroup = adminVerify:InvokeServer()
    if not authorized then return end

    UserInputService.InputBegan:Connect(function(input, processed)
        if processed then return end
        if input.KeyCode == Enum.KeyCode.Insert or input.KeyCode == Enum.KeyCode.RightShift then
            if me.PlayerGui:FindFirstChild("DeviosPanel") then
                me.PlayerGui.DeviosPanel:Destroy()
            else
                buildUI(adminLink, sessionSeed, activeBans, currentAdmins, currentGroup)
            end
        end
    end)
end

return DeviosUIController