--strict
local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local SharedApp = ReplicatedStorage:WaitForChild("App")
local ServerApp = ServerScriptService:WaitForChild("App")
local Cfg = require(SharedApp.Config.QBConfig)
local Types = require(SharedApp.Types.MovementTypes)
local Log = require(ServerApp.Debug.Logger)

type Violation = Types.Violation

local ViolationHandler = {}
local coolMap = {}

local function sendWebhook(player: Player, v: Violation)
    if Cfg.webhookUrl == "" or Cfg.webhookUrl == "YOUR_WEBHOOK_HERE" then return end
    task.spawn(function()
        pcall(function()
            local payload = {
                embeds = {{
                    title = "🚨 SENTINEL SECURITY ALARM",
                    color = 16711680, -- Vibrant red
                    fields = {
                        { name = "Identified Threat", value = player.Name .. " (" .. player.UserId .. ")", inline = true },
                        { name = "Severity Score", value = tostring(v.sev) .. " / 10", inline = true },
                        { name = "Vector Flag", value = tostring(v.kind), inline = true },
                        { name = "Breach Trace", value = v.msg, inline = false }
                    },
                    footer = { text = "DEVIOS Anti-Cheat Suite v5.0" },
                    timestamp = DateTime.now():ToIsoDate()
                }}
            }
            HttpService:PostAsync(
                Cfg.webhookUrl,
                HttpService:JSONEncode(payload),
                Enum.HttpContentType.ApplicationJson,
                false
            )
        end)
    end)
end

function ViolationHandler.report(player: Player, v: Violation)
    local k = player.UserId .. ":" .. v.kind
    local now = workspace:GetServerTimeNow()
    local last = coolMap[k]

    if last ~= nil and now - last < 1.5 then return end
    coolMap[k] = now

    Log.warn(string.format("Breach from %s: %s (Severity Level %d)", player.Name, v.msg, v.sev))
    sendWebhook(player, v)
end

function ViolationHandler.forget(player: Player)
    local prefix = player.UserId .. ":"
    for k in pairs(coolMap) do
        if string.sub(k, 1, #prefix) == prefix then
            coolMap[k] = nil
        end
    end
end

return table.freeze(ViolationHandler)