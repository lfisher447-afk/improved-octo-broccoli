--strict
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DataStoreService = game:GetService("DataStoreService")

local SharedApp = ReplicatedStorage:WaitForChild("App")
local ServerApp = ServerScriptService:WaitForChild("App")
local Cfg = require(SharedApp.Config.QBConfig)
local Remotes = require(SharedApp.Networking.AntiCheatRemotes)
local Packets = require(SharedApp.Networking.QBPackets)

local BanStore = DataStoreService:GetDataStore("DEVIOS_PersistentBans_v5")
local AdminPanelSecure = {}

local activeBans = {} -- [UserId] = {Reason: string, Date: string}
local dynamicAdmins = {} -- [Username] = true
local dynamicGroups = { GroupId = 0, MinRank = 255 }
local sessionSeeds = {} -- [Player] = seed

-- Map of custom ban reasons and exact suspicious outputs
local banReasonMessages = {
    [1] = "Speed limit breach detected.",
    [2] = "Noclip solid block wall penetration.",
    [3] = "Flight physics manipulation detected.",
    [4] = "Teleportation coordinates spoofed.",
    [14] = "Client sandbox metatable manipulation."
}

local function checkAdminPermissions(player: Player): boolean
    -- 1. Whitelist Checks
    if table.find(Cfg.ADMIN_USERIDS, player.UserId) then return true end
    if dynamicAdmins[player.Name] then return true end
    
    -- 2. Group Integration checks
    if dynamicGroups.GroupId > 0 then
        local ok, rank = pcall(function() return player:GetRankInGroup(dynamicGroups.GroupId) end)
        if ok and rank >= dynamicGroups.MinRank then
            return true
        end
    end
    
    return false
end

function AdminPanelSecure.init(endpoints: any)
    local adminVerify = Instance.new("RemoteFunction")
    adminVerify.Name = Remotes.adminVerify
    adminVerify.Parent = ReplicatedStorage:WaitForChild("App"):WaitForChild("Remotes")

    local adminLink = Instance.new("RemoteEvent")
    adminLink.Name = Remotes.adminLink
    adminLink.Parent = ReplicatedStorage:WaitForChild("App"):WaitForChild("Remotes")

    -- Check if arriving players are banned inside persistent storage
    Players.PlayerAdded:Connect(function(player)
        local key = "BAN_" .. tostring(player.UserId)
        local success, data = pcall(function() return BanStore:GetAsync(key) end)
        if success and data then
            player:Kick("\n[SENTINEL PERSISTENT BAN]\nReason: " .. tostring(data.Reason) .. "\nDate: " .. tostring(data.Date))
            return
        end

        if checkAdminPermissions(player) then
            sessionSeeds[player] = math.random(1000, 9999)
        end
    end)

    adminVerify.OnServerInvoke = function(player)
        if not checkAdminPermissions(player) then return false end
        return true, sessionSeeds[player], activeBans, dynamicAdmins, dynamicGroups
    end

    adminLink.OnServerEvent:Connect(function(player, action, targetUserId, token, extra)
        if not checkAdminPermissions(player) then
            player:Kick("[Sentinel Warn] Exploit call detected on core administrative RemoteEvent.")
            return
        end

        local seed = sessionSeeds[player]
        if not seed then return end

        -- Cryptographic Anti-Manipulation verification checks
        local actionValue = (action == "Kick" and 10) or (action == "Ban" and 20) or (action == "Bring" and 30) or (action == "Goto" and 40) or (action == "SaveRoles" and 50) or 0
        local expectedToken = Packets.generateHash(seed, player.UserId, actionValue)
        if token ~= expectedToken then
            player:Kick("[DEVIOS Error] Administrative execution integrity check failed.")
            return
        end

        local target = Players:GetPlayerByUserId(targetUserId)

        if action == "Kick" and target then
            target:Kick("[Devios Terminated] " .. (extra or "Exited by admin."))
        elseif action == "Ban" then
            local reason = extra or "Inappropriate gameplay patterns detected."
            local dateStr = os.date("%Y-%m-%d %H:%M:%S")
            activeBans[tostring(targetUserId)] = {Reason = reason, Date = dateStr}
            
            pcall(function()
                BanStore:SetAsync("BAN_" .. tostring(targetUserId), {Reason = reason, Date = dateStr})
            end)

            if target then
                target:Kick("\n[SENTINEL PERMANENT BAN]\nReason: " .. reason .. "\nDate: " .. dateStr)
            end
        elseif action == "Bring" and target then
            local pChar = player.Character
            local tChar = target.Character
            if pChar and tChar then
                tChar:PivotTo(pChar:GetPivot() * CFrame.new(4, 0, 0))
            end
        elseif action == "Goto" and target then
            local pChar = player.Character
            local tChar = target.Character
            if pChar and tChar then
                pChar:PivotTo(tChar:GetPivot() * CFrame.new(-4, 0, 0))
            end
        elseif action == "SaveRoles" and typeof(extra) == "table" then
            -- Mutate dynamic admins and group config in server-memory
            table.clear(dynamicAdmins)
            if extra.Admins then
                for _, name in ipairs(extra.Admins) do
                    dynamicAdmins[name] = true
                end
            end
            if extra.Group then
                dynamicGroups.GroupId = tonumber(extra.Group.GroupId) or 0
                dynamicGroups.MinRank = tonumber(extra.Group.MinRank) or 255
            end
        end
    end)
end

function AdminPanelSecure.logAutoBan(player: Player, violationType: number, details: string)
    local dateStr = os.date("%Y-%m-%d %H:%M:%S")
    local msg = banReasonMessages[violationType] or "Suspicious activity detected."
    local fullMessage = msg .. " | Trace: " .. details
    
    pcall(function()
        BanStore:SetAsync("BAN_" .. tostring(player.UserId), {Reason = fullMessage, Date = dateStr})
    end)
    
    player:Kick("\n[SENTINEL AUTOMATED BAN]\nReason: " .. fullMessage .. "\nDate: " .. dateStr)
end

return AdminPanelSecure