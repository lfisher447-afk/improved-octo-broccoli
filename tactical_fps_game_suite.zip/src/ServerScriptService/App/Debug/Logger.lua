--strict
local Logger = {}
local enabled = true

function Logger.enable(state: boolean)
    enabled = state
end

function Logger.isOn(): boolean
    return enabled
end

function Logger.info(msg: string)
    if enabled then
        print("[SENTINEL INFO]", msg)
    end
end

function Logger.warn(msg: string)
    warn("[SENTINEL ALARM]", msg)
end

return table.freeze(Logger)