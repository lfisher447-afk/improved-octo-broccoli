--!strict
local ProceduralModeler = {}

local function createPart(parent: Instance, size: Vector3, color: Color3, material: Enum.Material): Part
    local p = Instance.new("Part")
    p.Size = size
    p.Color = color
    p.Material = material
    p.CanCollide = false
    p.Anchored = false
    p.Parent = parent
    return p
end

-- Builds a highly detailed procedural 3D model for tactical weapons
function ProceduralModeler.buildWeapon(modelType: string): Model
    local model = Instance.new("Model")
    model.Name = modelType
    
    local main = createPart(model, Vector3.new(0.3, 0.5, 3), Color3.fromRGB(20, 20, 20), Enum.Material.Metal)
    main.Name = "Handle"
    
    local barrel = createPart(model, Vector3.new(0.2, 0.2, 2.5), Color3.fromRGB(40, 40, 40), Enum.Material.Metal)
    barrel.Position = main.Position + Vector3.new(0, 0.25, -1.8)
    
    local weld = Instance.new("WeldConstraint")
    weld.Part0 = main
    weld.Part1 = barrel
    weld.Parent = main
    
    if modelType == "M4A1" then
        -- Picatinny rails and handguard
        local handguard = createPart(model, Vector3.new(0.4, 0.4, 1.8), Color3.fromRGB(50, 45, 40), Enum.Material.Pebble)
        handguard.Position = main.Position + Vector3.new(0, 0.25, -1.2)
        local w = Instance.new("WeldConstraint")
        w.Part0 = main
        w.Part1 = handguard
        w.Parent = main
    elseif modelType == "DLQ33" then
        -- Heavy optic scope
        local scope = createPart(model, Vector3.new(0.25, 0.25, 1.2), Color3.fromRGB(15, 15, 15), Enum.Material.Metal)
        scope.Position = main.Position + Vector3.new(0, 0.5, -0.2)
        local w = Instance.new("WeldConstraint")
        w.Part0 = main
        w.Part1 = scope
        w.Parent = main
    elseif modelType == "Saqire367" then
        -- Majestic dragon scope procedural design
        local scopeBase = createPart(model, Vector3.new(0.3, 0.3, 1.5), Color3.fromRGB(218, 165, 32), Enum.Material.Neon) -- Gold Glowing base
        scopeBase.Position = main.Position + Vector3.new(0, 0.6, -0.2)
        local wBase = Instance.new("WeldConstraint")
        wBase.Part0 = main
        wBase.Part1 = scopeBase
        wBase.Parent = main
        
        -- Procedural coiled Wedges resembling a dragon body wrapping the scope
        for i = 1, 5 do
            local part = Instance.new("WedgePart")
            part.Size = Vector3.new(0.35, 0.35, 0.3)
            part.Color = Color3.fromRGB(139, 0, 0) -- Dark Crimson Dragon scale
            part.Material = Enum.Material.Slate
            part.CanCollide = false
            part.Position = scopeBase.Position + Vector3.new(0, 0.1, -0.6 + (i * 0.25))
            part.Orientation = Vector3.new(0, i * 45, 0)
            part.Parent = model
            
            local w = Instance.new("WeldConstraint")
            w.Part0 = scopeBase
            w.Part1 = part
            w.Parent = scopeBase
        end
    end
    
    model.PrimaryPart = main
    return model
end

return ProceduralModeler