# SiegeFPS: The Ultimate Roblox First-Person Shooter
A high-fidelity tactical shooter engine built in Roblox. Features Rainbow Six Siege lean physics, procedural 3D weapon generation, a 5-category aim trainer, an Arsenal-style progression system, and a god-tier integrated anti-cheat.

## Key Features & Detections (100+ Features)
- **R6 Tactical Camera & Leaning**: Spring-stabilized Q and E lean offsets. Camera roll ($10^{\circ}$ tilt) and lateral position shifts (1.5 studs).
- **Procedural Weapon Modeler**: Generates high-detail 3D guns (M4A1, DLQ-33, and the Saqire 367 sniper with its coiled golden dragon scope) on-the-fly using 3D parts.
- **5-Category Aim Trainer**: Spawns targets across Gridshot, Microshot, Tracking, Reflex, and Wallburst maps.
- **Arsenal Progression & Shop**: Earn currency on target hits/player kills to buy skins, background cards, and upgrade weapon parameters.
- **God-Tier Anti-Cheat Integration**: Core protections including 3D OBB Slab-Test hitbox verification, smoothness/jerk input auditing, active hook healing, and cryptographic heartbeat handshakes.

## Installation
1. Extract this zip file.
2. Initialize and compile using your preferred Rojo toolchain.
3. Open in Roblox Studio and run!
