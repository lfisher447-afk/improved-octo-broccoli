--strict
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local SharedApp = ReplicatedStorage:WaitForChild("App")
local ServerApp = ServerScriptService:WaitForChild("App")
local Reason = require(SharedApp.Enums.Reason)
local Violations = require(ServerApp.SubServices.ViolationHandler)

local BypassChecks = {}
local clientStates = {} -- [Player] = { stamp: number, challenge: number }

function BypassChecks.initHandshake(remote: RemoteEvent)
    task.spawn(function()
        while true do
            task.wait(5)
            local challenge = math.random(100000, 999999)
            for _, player in ipairs(Players:GetPlayers()) do
                clientStates[player] = { stamp = os.clock(), challenge = challenge }
                remote:FireClient(player, "SecHandshake", challenge)
            end
        end
    end)

    remote.OnServerEvent:Connect(function(player, response, token)
        if response ~= "HandshakeResponse" then return end
        local state = clientStates[player]
        if not state then return end

        local expected = (state.challenge * 2) + 12
        if token ~= expected then
            Violations.report(player, { kind = Reason.MetamethodHook, sev = 8, msg = "Secure sandbox cryptoken verification failed", correct = false })
        else
            clientStates[player] = nil -- Handshake successfully verified
        end
    end)
end

return BypassChecks