--strict
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerScriptService = game:GetService("ServerScriptService")

local SharedApp = ReplicatedStorage:WaitForChild("App")
local ServerApp = ServerScriptService:WaitForChild("App")
local Cfg = require(SharedApp.Config.QBConfig)
local Reason = require(SharedApp.Enums.Reason)
local Violations = require(ServerApp.SubServices.ViolationHandler)

local RemoteEventSecurity = {}

local function isWhitelisted(remoteName: string): boolean
    if not Cfg.RemoteEventSecurity.StrictWhitelistEnabled then return true end
    return table.find(Cfg.RemoteEventSecurity.WhitelistedRemoteEvents, remoteName) ~= nil
end

function RemoteEventSecurity.init()
    for _, descendant in ipairs(ReplicatedStorage:GetDescendants()) do
        if descendant:IsA("RemoteEvent") then
            descendant.OnServerEvent:Connect(function(player, ...)
                local name = descendant.Name
                local now = os.time()
                
                -- 1. Whitelist Verification
                if not isWhitelisted(name) then
                    Violations.report(player, { kind = Reason.SpoofedPacket, sev = 8, msg = "Fired non-whitelisted remote event: " .. name, correct = false })
                    player:Kick("[DEVIOS Security Exception] Remote interface whitelist violation.")
                    return
                end
                
                -- 2. Argument Verification (Ensures non-empty clean arguments)
                if Cfg.RemoteEventSecurity.ArgumentValidationEnabled then
                    local args = {...}
                    for _, arg in ipairs(args) do
                        if typeof(arg) == "table" and getmetatable(arg) ~= nil then
                            Violations.report(player, { kind = Reason.MetamethodHook, sev = 7, msg = "Injected custom metatables inside remote arguments", correct = false })
                            return
                        end
                    end
                end
                
                -- 3. Distance Verification (Physical checks for interaction remotes)
                if Cfg.RemoteEventSecurity.EnableDistanceCheck and (name == "PurchaseItem" or name == "Interact") then
                    local char = player.Character
                    local hrp = char and char:FindFirstChild("HumanoidRootPart")
                    local targetObj = select(1, ...)
                    if hrp and typeof(targetObj) == "Instance" and targetObj:IsA("BasePart") then
                        local dist = (hrp.Position - targetObj.Position).Magnitude
                        if dist > Cfg.RemoteEventSecurity.MaxRemoteDistance then
                            Violations.report(player, { kind = Reason.Teleport, sev = 6, msg = "Triggered interaction remote across illegal distance limits", correct = false })
                            return
                        end
                    end
                end
            end)
        end
    end
end

return RemoteEventSecurity