--strict
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SharedApp = ReplicatedStorage:WaitForChild("App")
local Names = require(SharedApp.Networking.AntiCheatRemotes)

local Remotes = {}

local function fetchFolder(parent: Instance, name: string): Folder
    local existing = parent:FindFirstChild(name)
    if existing and existing:IsA("Folder") then
        return existing
    end
    local f = Instance.new("Folder")
    f.Name = name
    f.Parent = parent
    return f
end

local function fetchRemote(parent: Instance, name: string): RemoteEvent
    local existing = parent:FindFirstChild(name)
    if existing and existing:IsA("RemoteEvent") then
        return existing
    end
    local r = Instance.new("RemoteEvent")
    r.Name = name
    r.Parent = parent
    return r
end

function Remotes.build()
    local root = fetchFolder(SharedApp, "Remotes")
    local container = fetchFolder(root, Names.folder)
    return {
        sample = fetchRemote(container, Names.sample),
        fix = fetchRemote(container, Names.correction),
        handshake = fetchRemote(container, Names.handshake),
    }
end

return table.freeze(Remotes)