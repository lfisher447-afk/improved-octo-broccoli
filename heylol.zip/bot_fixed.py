import discord
from discord.ext import commands
from discord.ui import Button, View, Select, button
import os
import subprocess
import uuid
import shutil
import asyncio
import base64
import requests

TOKEN = os.getenv('DISCORD_TOKEN')

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='.', intents=intents)

# Paths to deobfuscators
PROMETHEUS_DEOB_PATH = "/home/ubuntu/Prometheus-Deobfuscator/pol.py"  # 0x251 - Better alternative
IB2_PATH = "/home/ubuntu/IronbrewDeobfuscator/src/bin/Release/net8.0/IronbrewDeobfuscator"
SIX_ZENS_PATH = "/home/ubuntu/Lua-Deobfuscator/index.js"  # Universal dumper
UNLUAC_PATH = "/home/ubuntu/unluac.jar"
MEDAL_SERVER_PATH = "/home/ubuntu/medal-server"

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')
    # Start medal server in background if not running
    try:
        subprocess.Popen([MEDAL_SERVER_PATH], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print("Medal server started.")
    except Exception as e:
        print(f"Failed to start medal server: {e}")

async def decompile_luac(input_path):
    """Try to decompile a .luac file using unluac."""
    output_path = input_path + ".decompiled.lua"
    try:
        process = await asyncio.create_subprocess_exec(
            "java", "-jar", UNLUAC_PATH, input_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=30)
        if process.returncode == 0:
            with open(output_path, "wb") as f:
                f.write(stdout)
            return output_path
    except:
        pass
    return None

class DeobfDropdown(Select):
    """Dropdown menu for selecting deobfuscation method."""
    def __init__(self, input_path, original_filename):
        self.input_path = input_path
        self.original_filename = original_filename
        
        options = [
            discord.SelectOption(label="Prometheus Deobfuscator", value="prometheus_deob", description="Advanced multi-layer deobfuscation (Prometheus/Moonsec/V3)"),
            discord.SelectOption(label="IronBrew 2", value="ib2", description="IronBrew 2 deobfuscator"),
            discord.SelectOption(label="Medal (LuaU)", value="medal", description="LuaU bytecode decompiler"),
            discord.SelectOption(label="Universal Dumper", value="universal", description="Universal Lua dumper (MoonSec V2, IronBrew, AztupBrew)"),
            discord.SelectOption(label="Unluac", value="unluac", description="Lua 5.1 bytecode decompiler"),
        ]
        
        super().__init__(
            placeholder="Choose a deobfuscation method...",
            min_values=1,
            max_values=1,
            options=options
        )
    
    async def callback(self, interaction: discord.Interaction):
        method = self.values[0]
        
        if method == "prometheus_deob":
            await self.deobf_prometheus_deob(interaction)
        elif method == "ib2":
            await self.deobf_ib2(interaction)
        elif method == "medal":
            await self.deobf_medal(interaction)
        elif method == "universal":
            await self.deobf_universal(interaction)
        elif method == "unluac":
            await self.deobf_unluac(interaction)
    
    async def send_results(self, interaction, method_name, lua_path, luac_path=None):
        """Send deobfuscation results to user."""
        files = []
        if lua_path and os.path.exists(lua_path):
            files.append(discord.File(lua_path, filename="deobfuscated.lua"))
        if luac_path and os.path.exists(luac_path):
            files.append(discord.File(luac_path, filename="deobfuscated.luac"))
        
        if files:
            success_embed = discord.Embed(
                title="✅ Deobfuscation Complete!",
                description=f"**Method:** {method_name}\nSent both .lua and .luac for PC/Mobile compatibility.",
                color=discord.Color.green()
            )
            await interaction.followup.send(embed=success_embed, files=files)
        else:
            fail_embed = discord.Embed(
                title="❌ Deobfuscation Failed",
                description=f"**Method:** {method_name}\nNo output generated.",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=fail_embed)
    
    async def run_generic_deobf(self, interaction, method_name, cmd_args, output_filename):
        """Generic deobfuscation runner for command-based tools."""
        embed = discord.Embed(
            title="⏳ Deobfuscating...",
            description=f"**Method:** {method_name}\n**File:** `{self.original_filename}`",
            color=discord.Color.blue()
        )
        await interaction.response.defer()
        await interaction.followup.send(embed=embed)
        
        output_path = f"/tmp/{uuid.uuid4()}.lua"
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd_args(self.input_path, output_path),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=120)
            
            if os.path.exists(output_path) and os.path.getsize(output_path) > 0:
                # If it's a .luac, try to decompile it for mobile
                decompiled = await decompile_luac(output_path)
                await self.send_results(interaction, method_name, decompiled or output_path, output_path if decompiled else None)
            else:
                error_msg = stderr.decode() or stdout.decode() or "Unknown error"
                fail_embed = discord.Embed(
                    title="❌ Deobfuscation Failed",
                    description=f"**Method:** {method_name}\n**Error:** ```{error_msg[:1000]}```",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=fail_embed)
        except asyncio.TimeoutError:
            fail_embed = discord.Embed(
                title="❌ Timeout",
                description=f"**Method:** {method_name}\nDeobfuscation took too long (>120s)",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=fail_embed)
        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)}")
        finally:
            if os.path.exists(output_path):
                os.remove(output_path)
    
    # Individual deobfuscation methods
    
    async def deobf_prometheus_deob(self, interaction: discord.Interaction):
        """Prometheus Deobfuscator (0x251) - Advanced multi-layer deobfuscation."""
        await self.run_generic_deobf(
            interaction,
            "Prometheus Deobfuscator",
            lambda inp, out: ["python3", PROMETHEUS_DEOB_PATH, inp],
            "deobfuscated_prometheus_deob.lua"
        )
    
    async def deobf_ib2(self, interaction: discord.Interaction):
        """IronBrew 2 deobfuscator."""
        await self.run_generic_deobf(
            interaction,
            "IronBrew 2",
            lambda inp, out: ["dotnet", IB2_PATH + ".dll", "-t", "ib2", "-f", inp, "-o", out],
            "deobfuscated_ib2.lua"
        )
    
    async def deobf_medal(self, interaction: discord.Interaction):
        """Medal LuaU decompiler."""
        embed = discord.Embed(
            title="⏳ Decompiling...",
            description=f"**Method:** Medal (LuaU)\n**File:** `{self.original_filename}`",
            color=discord.Color.blue()
        )
        await interaction.response.defer()
        await interaction.followup.send(embed=embed)
        
        try:
            with open(self.input_path, "rb") as f:
                bytecode = f.read()
            encoded = base64.b64encode(bytecode).decode()
            
            response = requests.post("http://localhost:3000/decompile", data=encoded, timeout=30)
            if response.status_code == 200:
                output_path = f"/tmp/{uuid.uuid4()}.lua"
                with open(output_path, "w") as f:
                    f.write(response.text)
                await self.send_results(interaction, "Medal (LuaU)", output_path)
                os.remove(output_path)
            else:
                await interaction.followup.send(f"❌ Medal decompiler failed with status {response.status_code}")
        except Exception as e:
            await interaction.followup.send(f"❌ Medal error: {e}")
    
    async def deobf_universal(self, interaction: discord.Interaction):
        """Universal Dumper (SixZens) - Works with MoonSec V2, IronBrew, AztupBrew."""
        sixzens_dir = os.path.dirname(SIX_ZENS_PATH)
        sixzens_input = os.path.join(sixzens_dir, "input.lua")
        sixzens_output = os.path.join(sixzens_dir, "output.luac")
        shutil.copy(self.input_path, sixzens_input)
        
        await self.run_generic_deobf(
            interaction,
            "Universal Dumper",
            lambda inp, out: ["node", SIX_ZENS_PATH],
            "deobfuscated_universal.lua"
        )
    
    async def deobf_unluac(self, interaction: discord.Interaction):
        """Unluac - Lua 5.1 bytecode decompiler."""
        embed = discord.Embed(
            title="⏳ Decompiling...",
            description=f"**Method:** Unluac\n**File:** `{self.original_filename}`",
            color=discord.Color.blue()
        )
        await interaction.response.defer()
        await interaction.followup.send(embed=embed)
        
        output_path = f"/tmp/{uuid.uuid4()}.lua"
        try:
            process = await asyncio.create_subprocess_exec(
                "java", "-jar", UNLUAC_PATH, self.input_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=60)
            
            if process.returncode == 0:
                with open(output_path, "w") as f:
                    f.write(stdout.decode())
                await self.send_results(interaction, "Unluac", output_path)
            else:
                error_msg = stderr.decode() or "Unknown error"
                fail_embed = discord.Embed(
                    title="❌ Decompilation Failed",
                    description=f"**Method:** Unluac\n**Error:** ```{error_msg[:1000]}```",
                    color=discord.Color.red()
                )
                await interaction.followup.send(embed=fail_embed)
        except asyncio.TimeoutError:
            fail_embed = discord.Embed(
                title="❌ Timeout",
                description="Unluac decompilation took too long (>60s)",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=fail_embed)
        except Exception as e:
            await interaction.followup.send(f"❌ An error occurred: {str(e)}")
        finally:
            if os.path.exists(output_path):
                os.remove(output_path)

class DeobfView(View):
    """View containing the dropdown for deobfuscation method selection."""
    def __init__(self, input_path, original_filename):
        super().__init__(timeout=300)  # 5 minute timeout
        self.input_path = input_path
        self.original_filename = original_filename
        
        # Add dropdown to view
        self.add_item(DeobfDropdown(input_path, original_filename))

@bot.command(name="l")
async def l_command(ctx):
    """Main deobfuscation command - attach a Lua or text file."""
    if not ctx.message.attachments:
        await ctx.send("❌ Please attach a Lua or Text file.")
        return

    attachment = ctx.message.attachments[0]
    input_path = f"/tmp/{uuid.uuid4()}.lua"
    await attachment.save(input_path)

    embed = discord.Embed(
        title="🔓 Lua Deobfuscator v3",
        description=f"**File:** `{attachment.filename}`\n\nSelect a deobfuscation method from the dropdown. Both .lua and .luac will be sent if possible.",
        color=discord.Color.purple()
    )
    
    view = DeobfView(input_path, attachment.filename)
    await ctx.send(embed=embed, view=view)

if __name__ == "__main__":
    bot.run(TOKEN)
