"""
Bot Configuration - All Tool Paths
Update these paths based on your installation
"""

import os

# Base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Deobfuscator tool paths
TOOLS = {
    "PROMETHEUS_DEOB": os.path.join(BASE_DIR, "Prometheus-DeobfuscatorV2/src/deob/cli.lua"),
    "PROMETHEUS_DEOB_NEW": os.path.join(BASE_DIR, "Prometheus-Deobfuscator/pol.py"),  # Alternative
    "IB2": os.path.join(BASE_DIR, "IronbrewDeobfuscator/src/bin/Release/net8.0/IronbrewDeobfuscator.dll"),
    "SIX_ZENS": os.path.join(BASE_DIR, "Lua-Deobfuscator/index.js"),
    "UNLUAC": os.path.join(BASE_DIR, "unluac.jar"),
    "MEDAL_SERVER": os.path.join(BASE_DIR, "medal-decompiler/target/release/medal-server"),
    "LURAPH": os.path.join(BASE_DIR, "LuraphDeobfuscator/luraph_deobfuscator.py"),
    "THE_BIG_UNVEILR": os.path.join(BASE_DIR, "the-big-unveilr-v1/hi.luau"),
}

# Verify paths
def verify_paths():
    """Check which tools are available"""
    available = {}
    for tool_name, tool_path in TOOLS.items():
        if os.path.exists(tool_path):
            available[tool_name] = tool_path
            print(f"✓ {tool_name}: {tool_path}")
        else:
            print(f"✗ {tool_name}: NOT FOUND - {tool_path}")
    return available

if __name__ == "__main__":
    print("Checking available deobfuscation tools...")
    verify_paths()
